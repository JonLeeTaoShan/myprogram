

/*crc_url.h*/

#ifndef __CRC_URL_H_
#define __CRC_URL_H_

#include "public.h"

int check_url(PROTOCOL_PARSE *pPtcParse);
int crc_url_init();

int crc_url_add(PROTOCOL_PARSE *pPtcParse);


#endif //__CRC_URL_H_


